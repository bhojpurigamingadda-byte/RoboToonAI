package com.robottoon.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF101426)
private val Panel = Color(0xFF1B2440)
private val Purple = Color(0xFF8065FF)
private val Muted = Color(0xFFB8C1D9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoboToonApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoboToonApp() {
    var script by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Roblox 3D") }
    var quality by remember { mutableStateOf("Fast") }
    var voice by remember { mutableStateOf("Hindi • Male narrator") }
    var captions by remember { mutableStateOf("Bold viral captions") }
    var result by remember { mutableStateOf("") }
    val styles = listOf("Roblox 3D", "Stickman", "2D Cartoon", "3D Cartoon")
    val voices = listOf("Hindi • Male narrator", "Hindi • Female narrator", "English • Male narrator", "English • Female narrator", "Funny character voices")
    val captionStyles = listOf("Bold viral captions", "Neon captions", "Clean subtitles", "Karaoke word highlight")

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("ROBOT OON AI".replace(" ", ""), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Turn your script into a story.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("Paste a script. Choose a look. Plan your animated video.", color = Muted, fontSize = 14.sp)

            SectionTitle("YOUR SCRIPT")
            OutlinedTextField(
                value = script, onValueChange = { script = it },
                modifier = Modifier.fillMaxWidth().height(180.dp),
                placeholder = { Text("Paste your story or dialogue here...") },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF3A4564),
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
                )
            )

            SectionTitle("ANIMATION STYLE")
            ChoiceChips(styles, style) { style = it }

            SectionTitle("VIDEO QUALITY")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QualityCard("Fast", "Quicker generation", quality == "Fast", Modifier.weight(1f)) { quality = "Fast" }
                QualityCard("Pro", "Richer 3D scenes", quality == "Pro", Modifier.weight(1f)) { quality = "Pro" }
            }

            SectionTitle("VOICE OVER")
            ChoiceChips(voices, voice) { voice = it }

            SectionTitle("CAPTION STYLE")
            ChoiceChips(captionStyles, captions) { captions = it }

            Button(
                onClick = {
                    result = if (script.isBlank()) "Please paste a script first." else
                        "Project settings saved locally.\\nStyle: $style\\nQuality: $quality\\nVoice: $voice\\nCaptions: $captions\\n\\nNext step: connect the AI scene, voice and video-rendering services to generate the MP4."
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) {
                Text("CREATE VIDEO PROJECT  ✦", fontWeight = FontWeight.Bold)
            }

            if (result.isNotBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Text(result, Modifier.padding(16.dp), color = Color.White, fontSize = 14.sp)
                }
            }
            Text("Prototype v0.1 • Video rendering/API connection is the next development phase.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChoiceChips(items: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { item ->
                    FilterChip(
                        selected = selected == item,
                        onClick = { onSelect(item) },
                        label = { Text(item, fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Purple,
                            selectedLabelColor = Color.White,
                            labelColor = Muted
                        )
                    )
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun QualityCard(title: String, subtitle: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF342B68) else Panel),
        border = if (selected) androidx.compose.foundation.BorderStroke(1.dp, Purple) else null,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}
